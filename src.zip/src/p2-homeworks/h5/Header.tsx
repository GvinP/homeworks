import React from 'react'

function Header() {
    return (
        <div>
            // add NavLinks

        </div>
    )
}

export default Header
